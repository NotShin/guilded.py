A Python wrapper for the Guilded API

Quick Example
-------------

.. code:: py

	import guilded

	client = guilded.Client(command_prefix = "!")

	client.run(email='', password='')